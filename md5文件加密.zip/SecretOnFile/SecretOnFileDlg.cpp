// SecretOnFileDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SecretOnFile.h"
#include "SecretOnFileDlg.h"
#include "Afxtempl.h"
#include "Md5.h"
#define MAXLEN 2000000 

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSecretOnFileDlg dialog

CSecretOnFileDlg::CSecretOnFileDlg(CWnd* pParent /*=*/)
	: CDialog(CSecretOnFileDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSecretOnFileDlg)
	m_strFilename = _T("");
	m_strPassword = _T("");
	m_nChoose = 0;
	m_nPassworddepth = 1;
	m_nCurrentdepth = 0;
	m_nAim = 0;
	m_bflag = false;
	m_bIsfirstrun = true;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSecretOnFileDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSecretOnFileDlg)
	DDX_Control(pDX, IDC_SPIN1, m_conPassworddepth);
	DDX_Text(pDX, IDC_FILENAME, m_strFilename);
	DDX_Text(pDX, IDC_PASSWORD, m_strPassword);
	DDV_MaxChars(pDX, m_strPassword, 255);
	DDX_Radio(pDX, IDC_RADIO1, m_nChoose);
	DDX_Text(pDX, IDC_PASSWORDDEPTH, m_nPassworddepth);
	DDV_MinMaxInt(pDX, m_nPassworddepth, 1, 255);
	DDX_Radio(pDX, IDC_RADIO3, m_nAim);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSecretOnFileDlg, CDialog)
	//{{AFX_MSG_MAP(CSecretOnFileDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_LIST, OnList)
	ON_BN_CLICKED(IDC_PASSWORDSTYLE, OnPasswordstyle)
	ON_WM_DROPFILES()
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_EN_CHANGE(IDC_PASSWORD, OnChangePassword)
	ON_EN_CHANGE(IDC_FILENAME, OnChangeFilename)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSecretOnFileDlg message handlers

BOOL CSecretOnFileDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_conPassworddepth.SetRange(1,255);
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu !=NULL )
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSecretOnFileDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSecretOnFileDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}

	if(m_bIsfirstrun)
	{
		
		char chname[512], * parameter;
		CString commondline;
		::GetModuleFileName(NULL,chname,512);
		parameter = GetCommandLine();
		int black = 0,quote = 0,paralen,t;
		for(int i=0;parameter[i]!=0;i++);
		for(;i>=0;i--)
		{
			if(parameter[i]==' ') parameter[i] = 0;
			if(parameter[i]!=' ' && parameter[i]!=0) break;
		}
		for(i=0;parameter[i]!=0;i++)
		{
			if(parameter[i]==' ') black = i;
			if(parameter[i]=='\"' && parameter[i+1]!=0) quote = i;
		}
		paralen = i -(parameter[i-1]=='\"');
		if(parameter[i-1]!='\"') i = black + 1;
		else i = quote + 1;
		for(t=0;i<paralen;i++,t++)
			parameter[t] = parameter[i];
		parameter[t] = 0;
		for(i=0;;i++)
			if((parameter[i]==0 && chname[i]==0) || parameter[i]!=chname[i]) break;
		if(parameter[i]!=chname[i])
		{
			m_bflag = true;
			m_strFilename = parameter;
		}
		else m_bflag = false;
		UpdateData(false);
		m_bIsfirstrun = false;
	}
	ScanFile();
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSecretOnFileDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSecretOnFileDlg::OnRadio1() 
{
	SetDlgItemText(IDC_README,"�ٶȿ죬�����ڳ���Ӣ�����ļ���������ļ���������ܻ���ܷǴ�Ӣ�����ļ�������ʹ�ô˷��������ܻ���ܴ�Ӣ�����ļ�������ѡ��ȫ������");
}

void CSecretOnFileDlg::OnRadio2() 
{
	SetDlgItemText(IDC_README,"�ٶ����ļ��Ĵ�С�����ȣ������������ļ�������ļ��ܴ󣬼��ܻ����ʱ�佫���ĺܳ������ܻ����2M���ϵ�Ӣ���ļ�������ʹ��ȫ������");
}

void CSecretOnFileDlg::OnList() 
{
	UpdateData(true);
	CFileDialog fileDlg(true);
	fileDlg.m_ofn.lpstrFilter="�����ļ�(*.*)\0*.*\0\0";
	if(IDOK == fileDlg.DoModal())
	{
		m_strFilename = fileDlg.GetPathName();
		GetActiveWindow()->SetWindowText(m_strFilename);
		UpdateData(false);
		GetDlgItem(IDC_PASSWORD)->SetFocus();
		m_bflag = true;
		CSecretOnFileDlg::ScanFile();
	}
}

void CSecretOnFileDlg::OnOK() 
{
	UpdateData(true);
	if(IDYES == MessageBox(m_nAim==0?"��ȷ��Ҫ�Դ��ļ����ܣ�":"��ȷ��Ҫ�Դ��ļ����ܣ�","ȷ��",MB_YESNO | MB_ICONQUESTION))
	{
		if(m_nAim == 0)
			AddSecret();
		else
			DeleteSecret();
	}
}

void CSecretOnFileDlg::OnPasswordstyle() 
{
	CString str;
	GetDlgItemText(IDC_PASSWORDSTYLE,str);
	CEdit *pEdit = (CEdit *)GetDlgItem(IDC_PASSWORD);
	if(str == "����")
	{
		SetDlgItemText(IDC_PASSWORDSTYLE, "����");
		pEdit->SetPasswordChar('*');
	}
	else
	{
		SetDlgItemText(IDC_PASSWORDSTYLE, "����");
		pEdit->SetPasswordChar(0);
	}
	pEdit->SetFocus();
}

void CSecretOnFileDlg::OnDropFiles(HDROP hDropInfo) 
{
	UpdateData(true);
	char lpszFileName[512];
	::DragQueryFile(hDropInfo, 0, lpszFileName, 512);
	::DragFinish(hDropInfo);
	m_strFilename = lpszFileName;
	UpdateData(false);
	this->SetWindowText(m_strFilename);
	GetDlgItem(IDC_PASSWORD)->SetFocus();
	m_bflag = true;
	CSecretOnFileDlg::ScanFile();
	this->SetForegroundWindow(); 
}

void CSecretOnFileDlg::ScanFile()
{
	UpdateData(true);
	m_nCurrentdepth = 0;
	m_conPassworddepth.SetRange(1,255);
	UpdateData(false);
	char chname[512];
	::GetModuleFileName(NULL,chname,512);
	if(chname == m_strFilename)
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		GetDlgItem(IDC_RADIO3)->EnableWindow(true);		
		GetDlgItem(IDC_RADIO4)->EnableWindow(true);
		SetDlgItemText(IDC_FILEINFO, "����ѡ���Լ�");
		return ;
	}
	CFileFind file;
	if(file.FindFile(m_strFilename))
	{
		this->SetWindowText(m_strFilename);
		GetDlgItem(IDC_PASSWORD)->SetFocus();
		CFile file(m_strFilename, CFile::typeBinary | CFile::modeRead);	
		unsigned char com[17]={"000SECRETONFILE0"};
		fileInfo[16] = com[16] = 0;
		com[2] = com[15] = 0xdf;
		if(file.GetLength()<49)
		{
			SetDlgItemText(IDC_FILEINFO, "�ļ�δ����");
			m_nAim = 0;
			UpdateData(false);
			GetDlgItem(IDC_RADIO3)->EnableWindow(true);		
			if(m_strPassword != "")	GetDlgItem(IDOK)->EnableWindow(true);
			else GetDlgItem(IDOK)->EnableWindow(false);
			GetDlgItem(IDC_RADIO4)->EnableWindow(false);
			return ;
		}
		file.Seek(-16,CFile::end);
		file.Read(fileInfo,16);
		file.Close();
		int pw = fileInfo[2] ^ com[2];
		for(int j=3;j<16;j++)
		{
			if(fileInfo[j] == (com[j] ^ pw))
				continue;
			SetDlgItemText(IDC_FILEINFO, "�ļ�δ����");
			m_nAim = 0;
			UpdateData(false);
			GetDlgItem(IDC_RADIO3)->EnableWindow(true);		
			if(m_strPassword != "")	GetDlgItem(IDOK)->EnableWindow(true);
			else GetDlgItem(IDOK)->EnableWindow(false);
			GetDlgItem(IDC_RADIO4)->EnableWindow(false);
			return ;
		}
		m_nCurrentdepth = fileInfo[0] ^ pw;
		if(m_bflag)	m_nPassworddepth = fileInfo[1] ^ pw;
		UpdateData(false);
		CString str;
		str.Format("�ļ�����%d��",m_nCurrentdepth);
		SetDlgItemText(IDC_FILEINFO, str);
		if(m_nCurrentdepth == m_nPassworddepth)
		{
			m_nAim = 1;
			UpdateData(false);
			GetDlgItem(IDC_RADIO3)->EnableWindow(false);
		}
		else GetDlgItem(IDC_RADIO3)->EnableWindow(true);
		GetDlgItem(IDC_RADIO4)->EnableWindow(true);
		if(m_strPassword != "")	GetDlgItem(IDOK)->EnableWindow(true);
		else GetDlgItem(IDOK)->EnableWindow(false);
		m_conPassworddepth.SetRange(m_nAim==0?m_nCurrentdepth+1:m_nCurrentdepth==1?1:m_nCurrentdepth-1,255);
		return ;
	}
	SetDlgItemText(IDC_FILEINFO, "�ļ�������");
	GetDlgItem(IDOK)->EnableWindow(false);
	GetDlgItem(IDC_RADIO3)->EnableWindow(true);		
	GetDlgItem(IDC_RADIO4)->EnableWindow(true);
	this->SetWindowText("SecretOnFile-BeanJoy's production");
}


void CSecretOnFileDlg::OnChangePassword() 
{
	m_bflag = false;
	ScanFile();
}

void CSecretOnFileDlg::OnChangeFilename() 
{
	m_bflag = true;
	ScanFile();
}


void CSecretOnFileDlg::OnRadio4() 
{
	m_nAim = 1;
	if(m_nCurrentdepth ==0)
		m_conPassworddepth.SetRange(1,255);
	else
		m_conPassworddepth.SetRange(m_nCurrentdepth==1?1:m_nCurrentdepth-1,255);
}

void CSecretOnFileDlg::OnRadio3() 
{
	m_nAim = 0;
	m_conPassworddepth.SetRange(1+m_nCurrentdepth,255);	
	UpdateData(true);
	if(m_nPassworddepth<1+m_nCurrentdepth) m_nPassworddepth=1+m_nCurrentdepth;
	UpdateData(false);
}

void CSecretOnFileDlg::AddSecret()
{
	char tf[512];
	::GetEnvironmentVariable("temp",tf, 512);
	CString tempfile;
	tempfile.Format("%s\\$$secretonfile$$.tmp",tf);
	CFileStatus rStatus,tempstatus;
	CFile::GetStatus(m_strFilename,rStatus);
	tempstatus = rStatus;
	tempstatus.m_attribute = 0;
	::CopyFile(m_strFilename, tempfile, false);
	CFile::SetStatus(tempfile, tempstatus);

	m_nCurrentdepth ++;
	int len = (m_nCurrentdepth==1?0:16) + (m_nCurrentdepth-1) * 33;
	CFile file(m_strFilename, CFile::typeBinary | CFile::modeRead);	
	file.Seek(-len, CFile::end);
	unsigned char tmp[33];
	for(int i=0;i<m_nCurrentdepth-1;i++)
	{
		file.Read(tmp,32);
		tmp[32] = 0;
		pwMd5[i].Format("00000000000000000000000000000000");
		for(int j=0;j<32;j++) pwMd5[i].SetAt(j, tmp[j]);
	}
	unsigned char tm[17]={"000SECRETONFILE0"};
	tm[16] = 0;
	tm[2] = tm[15] = 0xdf;
	memmove(fileInfo, tm, 17);
	if(m_nCurrentdepth!=1)
	{	
		file.Read(pwInfo,m_nCurrentdepth-1);
		file.Read(fileInfo,16);
	}
	file.Close();
	pwMd5[m_nCurrentdepth-1] = md5.getMd5(m_strPassword + md5.getMd5(m_strPassword));
	int pw = fileInfo[3] ^ 'S';
	for(i=0;i<m_nCurrentdepth-1;i++)
	{
		for(int j=0;j<32;j++) pwMd5[i].SetAt(j, pwMd5[i].GetAt(j) ^ pw); 
		pwInfo[i] ^= pw;
	}
	if(m_nCurrentdepth!=1)
		for(i=0;i<16;i++) 
			fileInfo[i] ^= pw;
	for(i=0;i<m_nCurrentdepth-1;i++)
		if(pwMd5[i] == pwMd5[m_nCurrentdepth-1])
		{
			m_nCurrentdepth --;
			CFile::Remove(tempfile);
			MessageBox("�㲻���ô����������ܣ��뻻һ����������","ȡ��",MB_ICONEXCLAMATION);
			return ;
		}
	
	file.Open(tempfile, CFile::typeBinary | CFile::modeReadWrite);
	char *pBuf;
	DWORD dwFileLen;
	dwFileLen = file.GetLength();
	DWORD filelen = dwFileLen-len;
	if(m_nChoose==0) filelen = filelen<MAXLEN?filelen:MAXLEN;
	pBuf = new char[filelen];
	file.Read(pBuf,filelen);
	CString temp = pwMd5[m_nCurrentdepth-1] ;
	for(i=0;i<filelen;i++)
	{
		if(i%32==0) temp = md5.getMd5(m_strPassword + temp);
		pBuf[i] ^= temp.GetAt(i%32);		
	}
	file.SeekToBegin();
	file.Write(pBuf,filelen);
	file.Close();
	delete pBuf; 
	pBuf = NULL;	
	
	pwInfo[m_nCurrentdepth-1] = m_nChoose;
	fileInfo[0] = m_nCurrentdepth;
	fileInfo[1] = m_nPassworddepth;
	srand(::GetTickCount());
	pw = rand()%250+2;
	for(i=0; i<m_nCurrentdepth;i++)
	{
		for(int j=0;j<32;j++)
			pwMd5[i].SetAt(j, pwMd5[i].GetAt(j) ^ pw);
		pwInfo[i] ^= pw;
	}
	for(i=0;i<16;i++)
		fileInfo[i] ^= pw;
	
	file.Open(tempfile, CFile::typeBinary | CFile::modeReadWrite);
	file.SetLength(dwFileLen-len);
	file.SeekToEnd();
	for(i=0;i<m_nCurrentdepth;i++)
		file.Write(pwMd5[i], 32);
	file.Write(pwInfo, m_nCurrentdepth);
	file.Write(fileInfo, 16);
	file.Close();

	CFile::SetStatus(m_strFilename, tempstatus);
	::CopyFile(tempfile, m_strFilename, false);
	CFile::SetStatus(m_strFilename,rStatus);
	CFile::Remove(tempfile);
	m_bflag = true;
	ScanFile();
	MessageBox("���ܳɹ���","���",MB_ICONWARNING);
}

void CSecretOnFileDlg::DeleteSecret()
{
	char tf[512];
	::GetEnvironmentVariable("temp",tf, 512);
	CString tempfile;
	tempfile.Format("%s\\$$secretonfile$$.tmp",tf);
	CFileStatus rStatus,tempstatus;
	CFile::GetStatus(m_strFilename,rStatus);
	tempstatus = rStatus;
	tempstatus.m_attribute = 0;
	::CopyFile(m_strFilename, tempfile, false);
	CFile::SetStatus(tempfile, tempstatus);


	CFile file(m_strFilename, CFile::typeBinary | CFile::modeRead);	
	int len = 16 + m_nCurrentdepth * 33;
	file.Seek(-len, CFile::end);
	unsigned char tmp[33];
	for(int i=0;i<m_nCurrentdepth;i++)
	{
		file.Read(tmp,32);
		tmp[32] = 0;
		pwMd5[i].Format("00000000000000000000000000000000");
		for(int j=0;j<32;j++) pwMd5[i].SetAt(j, tmp[j]);
	}
	file.Read(pwInfo,m_nCurrentdepth);
	file.Read(fileInfo,16);
	file.Close();
	CString currentpw;
	currentpw = md5.getMd5(m_strPassword + md5.getMd5(m_strPassword));
	int pw = fileInfo[3] ^ 'S';
	for(i=0;i<m_nCurrentdepth;i++)
	{
		for(int j=0;j<32;j++) 
			pwMd5[i].SetAt(j, pwMd5[i].GetAt(j) ^ pw); 
		pwInfo[i] ^= pw;
	}
	for(i=0;i<16;i++) 
		fileInfo[i] ^= pw;

	for(int com=0;com<m_nCurrentdepth;com++) 
		if(currentpw==pwMd5[com] && m_nChoose==pwInfo[com]) break;
	if( com==m_nCurrentdepth)
	{
		CFile::Remove(tempfile);
		MessageBox("����������ʽ��ƥ�䣬�޷�����","���",MB_ICONERROR );
		return ;
	}
	file.Open(tempfile, CFile::typeBinary | CFile::modeReadWrite);
	char *pBuf;
	DWORD dwFileLen;
	dwFileLen = file.GetLength();
	DWORD filelen = dwFileLen-len;
	if(m_nChoose==0) filelen = filelen<MAXLEN?filelen:MAXLEN;
	pBuf = new char[filelen];
	file.Read(pBuf,filelen);
	CString temp = currentpw ;
	for(i=0;i<filelen;i++)
	{
		if(i%32==0) temp = md5.getMd5(m_strPassword + temp);
		pBuf[i] ^= temp.GetAt(i%32);		
	}
	file.SeekToBegin();
	file.Write(pBuf,filelen);
	file.SetLength(dwFileLen-len);
	file.Close();
	delete pBuf; 
	pBuf = NULL;	
	
	if(m_nCurrentdepth!=1)
	{
		m_nCurrentdepth --;
		fileInfo[0] = m_nCurrentdepth;
		fileInfo[1] = m_nPassworddepth;
		srand(::GetTickCount());
		pw = rand()%250+2;
		for(i=0; i<m_nCurrentdepth+1;i++)
		{
			for(int j=0;j<32;j++)
				pwMd5[i].SetAt(j, pwMd5[i].GetAt(j) ^ pw);
			pwInfo[i] ^= pw;
		}
		for(i=0;i<16;i++)
			fileInfo[i] ^= pw;
		file.Open(tempfile, CFile::typeBinary | CFile::modeReadWrite);
		file.SeekToEnd();
		for(i=0;i<m_nCurrentdepth+1;i++)
			if(i == com) continue;
			else file.Write(pwMd5[i], 32);
		for(i=0;i<m_nCurrentdepth+1;i++)
			if(i == com) continue;
			else file.Write(&pwInfo[i], 1);
		file.Write(fileInfo, 16);
		file.Close();
	}
	CFile::SetStatus(m_strFilename, tempstatus);
	::CopyFile(tempfile, m_strFilename, false);
	CFile::SetStatus(m_strFilename,rStatus);
	CFile::Remove(tempfile);
	m_bflag = true;
	ScanFile();
	MessageBox("���ܳɹ���","���",MB_ICONWARNING);
}

