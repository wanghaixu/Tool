// Md5.cpp: implementation of the CMd5 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Md5.h"
#include <Math.h>

#define PI 3.1415926535

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMd5::CMd5()
{
	m_cSrcString = NULL;
	int rr[64] = {	7, 12, 17, 22,  7, 12, 17, 22,  7, 12, 17, 22,  7, 12, 17, 22,
					5,  9, 14, 20,  5,  9, 14, 20,  5,  9, 14, 20,  5,  9, 14, 20,
					4, 11, 16, 23,  4, 11, 16, 23,  4, 11, 16, 23,  4, 11, 16, 23,
					6, 10, 15, 21,  6, 10, 15, 21,  6, 10, 15, 21,  6, 10, 15, 21};
	for(int i=0;i<64;i++) 
	{
		r[i] = rr[i];
		double j = sin(i+1);
		if(j<0) j = -1 * j;
		k[i] = j * (pow(2,32));
	}
}

CMd5::~CMd5()
{
}

void CMd5::Init(CString str)
{
	ULONGLONG strlen;
	strlen = str.GetLength(); /////////////////////////////////strlenΪ�����ַ����ı�������	
	if((strlen % 64) < 56) m_uLength = ((strlen / 64) + 1) * 64;
	else m_uLength = ((strlen / 64) + 2) * 64;   //////////////m_uLengthΪ����ĳ���
	m_cSrcString = new unsigned char [m_uLength];
	memmove(m_cSrcString, str, strlen);
	m_cSrcString[strlen] &= 0x80;
	for(int i=strlen+1;i<m_uLength;i++)
		m_cSrcString[i] &= 0x0;
	strlen *= 8;
	memmove(&m_cSrcString[m_uLength-8], &strlen, 8);

	/////////////////////////////////////////////////////////���ڲ��Լ���Ƿ����

/*	

	CString t1,t2;
	t1 = str;
	str.Empty();
	for(i=0;i<m_uLength;i++)
	{
		t2.Format("0x%0x ",m_cSrcString[i]);
		str += t2;
	}
	t1.Format("ԭ�����ַ���Ϊ:%s\n\n�����ַ���Ϊ:%s\n\nԭ���ĳ���Ϊ:%ld\n\n",
		t1,m_cSrcString,strlen);
	t2.Format("�ĺ�ĳ���Ϊ:%d\n\n16������ʾ:",m_uLength);
	str = t1 + t2 + str;
	AfxMessageBox(str);
*/
	
}

CString CMd5::getMd5(CString srcString)
{
	Init(srcString);
	h0 = 0x67452301;
	h1 = 0xEFCDAB89;
	h2 = 0x98BADCFE;
	h3 = 0x10325476;
	DWORD f, g, temp;;
	DWORD a, b, c, d;
	for(int j=0;j<m_uLength/64;j++)
	{
		a = h0; b = h1; c = h2; d = h3;
		for(int i=0;i<16;i++) memmove(&w[i],&m_cSrcString[j*64+i*4],4);

/*		
		CString str,tm;
		str.Format("\n\nw[0]-w[15]��16����ֵ��:\n");
		for(i=0;i<16;i++)
		{
			tm.Format("0x%0x ",w[i]);
			str += tm;
		}
		AfxMessageBox(str);
*/
		
		for(i=0;i<64;i++)
		{
			if(i>=0 && i<=15)
			{
				f = (b & c) | ((~b) & d);
				g = i;
			}
			else if(i>=16 && i<=31)
			{
				f = (d & b) | ((~d) & c);
				g = (5 * i +1) % 16;
			}
			else if(i>=32 && i<=47)
			{
				f = b ^ c ^ d;
				g = (3 * i + 5) % 16;
			}
			else if(i>=48 && i<=63)
			{
				f = c ^ ( b | ( ~d ) );
				g = (7 * i) % 16;
			}
			temp = d;
			d = c;
			c = b;
			b = b + leftrotate((a + f + k[i] + w[g]), r[i]);
			a = temp;
		}
		h0 += a;
		h1 += b;
		h2 += c;
		h3 += d;
	}

	if(m_cSrcString!=NULL)
	{
		delete m_cSrcString;
		m_cSrcString = NULL;
	}
	CString result,t;
	result.Empty();
	unsigned char ch[16];
	memmove(&ch[0], &h0, 4);
	memmove(&ch[4], &h1, 4);
	memmove(&ch[8], &h2, 4);
	memmove(&ch[12], &h3, 4);
	for(int i=0;i<16;i++)
	{
		t.Format("%02x",ch[i]);
		result += t;
	}
	return result; 
}

DWORD CMd5::leftrotate(DWORD x, int c)
{	
	return ((x << c) | x >> (32-c));
}