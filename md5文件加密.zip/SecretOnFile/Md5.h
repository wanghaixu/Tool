// Md5.h: interface for the CMd5 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MD5_H__1A63D260_C069_48D7_A1A1_FF1FA02552C7__INCLUDED_)
#define AFX_MD5_H__1A63D260_C069_48D7_A1A1_FF1FA02552C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMd5  
{
public:
	CString getMd5(CString srcString);
	CMd5();
	virtual ~CMd5();

private:
	void Init(CString str);
	unsigned char *m_cSrcString;//������������
	DWORD w[16];//ÿһ�ַ�������Ϣ
	ULONGLONG m_uLength;//������ܳ���
	int r[64];
	DWORD k[64];
	DWORD h0, h1, h2, h3;
	DWORD leftrotate(DWORD x, int c);
};

#endif // !defined(AFX_MD5_H__1A63D260_C069_48D7_A1A1_FF1FA02552C7__INCLUDED_)
