// SecretOnFileDlg.h : header file
//

#if !defined(AFX_SECRETONFILEDLG_H__C6ECD5AB_60F7_4075_8693_F81792501F75__INCLUDED_)
#define AFX_SECRETONFILEDLG_H__C6ECD5AB_60F7_4075_8693_F81792501F75__INCLUDED_

#include "Md5.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSecretOnFileDlg dialog

class CSecretOnFileDlg : public CDialog
{
// Construction
public:
	CSecretOnFileDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSecretOnFileDlg)
	enum { IDD = IDD_SECRETONFILE_DIALOG };
	CSpinButtonCtrl	m_conPassworddepth;
	CString	m_strFilename;
	CString	m_strPassword;
	int		m_nChoose;
	int		m_nCurrentdepth;
	int		m_nPassworddepth;
	int		m_nAim;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSecretOnFileDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSecretOnFileDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnList();
	virtual void OnOK();
	afx_msg void OnPasswordstyle();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnRadio4();
	afx_msg void OnRadio3();
	afx_msg void OnChangePassword();
	afx_msg void OnChangeFilename();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	bool m_bIsfirstrun;
	CString tempfile;
	BOOL m_bflag;
	CMd5 md5;
	CString pwMd5[255];//��Ÿ��������MD5ֵ
	unsigned char fileInfo[17];//�����������,�ж��Ƿ����
	unsigned char pwInfo[255];//�������Ĳ�����ʽ
	void ScanFile();//���ļ�����ɨ��
	void AddSecret();//���ļ�����
	void DeleteSecret();//���ļ�����
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SECRETONFILEDLG_H__C6ECD5AB_60F7_4075_8693_F81792501F75__INCLUDED_)
